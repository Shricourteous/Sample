import React, { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import jsQR from 'jsqr';
import axios from '../api';
// Using only the best-fit icons from your imports and adding a few for completeness/style
import { CloudUpload, Delete, Eye, Trash2, Upload, X, Users, ChevronLeft } from 'lucide-react'; 
// NOTE: I've replaced 'DeleteIcon', 'Trash', and 'View' with 'Trash2' and 'Eye' for consistency.

// Tunables for performance and UX
const PROCESS_FPS = 10; // Max QR processing rate
const MIN_CAPTURE_INTERVAL_MS = 1200; // Minimum time between auto-captures
const DOWNSCALE_WIDTH = 640; // Downscale width for QR processing

const Scanner = () => {
  const webcamRef = useRef(null);
  const processCanvasRef = useRef(null); // reused canvas for QR decoding
  const captureCanvasRef = useRef(null); // reused canvas for high-res capture

  const [currentStudentName, setCurrentStudentName] = useState('');
  const [scannedImages, setScannedImages] = useState([]);
  const [currentQr, setCurrentQr] = useState(null);
  const [isScanning, setIsScanning] = useState(true);
  const [error, setError] = useState('');
  const [groupsByQr, setGroupsByQr] = useState({}); // { [qr]: { qrCode, studentName, images: [{image, ts}] } }

  // UI state: modals and viewer
  const [showStudentsModal, setShowStudentsModal] = useState(false);
  const [studentModalQr, setStudentModalQr] = useState(null); // which student to view in modal
  const [viewerImage, setViewerImage] = useState(null); // { qrCode, ts, image }

  // Refs for timing and caching to avoid re-renders in tight loop
  const lastCaptureAtRef = useRef(0);
  const lastProcessAtRef = useRef(0);
  const cachedStudentByQrRef = useRef(new Map());
  const rafRef = useRef(null);

  const ensureCanvases = useCallback((video) => {
    if (!processCanvasRef.current) {
      processCanvasRef.current = document.createElement('canvas');
    }
    if (!captureCanvasRef.current) {
      captureCanvasRef.current = document.createElement('canvas');
    }

    // Setup sizes
    const aspect = video.videoHeight / Math.max(1, video.videoWidth);
    const targetW = Math.min(DOWNSCALE_WIDTH, video.videoWidth);
    const targetH = Math.round(targetW * aspect);
    processCanvasRef.current.width = targetW;
    processCanvasRef.current.height = targetH;

    // Full-res capture canvas uses the video’s native resolution
    captureCanvasRef.current.width = video.videoWidth;
    captureCanvasRef.current.height = video.videoHeight;
  }, []);

  const fetchStudent = useCallback(async (qrValue) => {
    // Serve from cache if available
    if (cachedStudentByQrRef.current.has(qrValue)) {
      const cached = cachedStudentByQrRef.current.get(qrValue);
      setCurrentStudentName(cached);
      // propagate to groups store
      setGroupsByQr((prev) => (prev[qrValue] ? { ...prev, [qrValue]: { ...prev[qrValue], studentName: cached } } : prev));
      return cached;
    }
    try {
      const response = await axios.post('/get_students_name/', { qrCode: qrValue });
      const { studentName } = response.data;
      cachedStudentByQrRef.current.set(qrValue, studentName || '');
      setCurrentStudentName(studentName || '');
      // propagate to groups store
      setGroupsByQr((prev) => (prev[qrValue] ? { ...prev, [qrValue]: { ...prev[qrValue], studentName: studentName || '' } } : prev));
      return studentName || '';
    } catch (err) {
      console.error(err);
      setError('Failed to fetch student name');
      return '';
    }
  }, []);

  const captureHighResImage = useCallback((video) => {
    if (!captureCanvasRef.current) return null;
    const c = captureCanvasRef.current;
    const ctx = c.getContext('2d', { willReadFrequently: false });
    ctx.drawImage(video, 0, 0, c.width, c.height);
    // High-quality JPEG
    return c.toDataURL('image/jpeg', 0.9);
  }, []);

  const processFrame = useCallback(async (nowTs) => {
    if (!isScanning || !webcamRef.current) return;

    const video = webcamRef.current.video;
    if (!video || video.readyState < 2) return; // video not ready

    // Throttle processing to PROCESS_FPS
    const sinceLast = nowTs - lastProcessAtRef.current;
    const minDelta = 1000 / PROCESS_FPS;
    if (sinceLast < minDelta) return;
    lastProcessAtRef.current = nowTs;

    ensureCanvases(video);

    // Downscale and read pixels for QR
    const pc = processCanvasRef.current;
    const pctx = pc.getContext('2d', { willReadFrequently: true });
    pctx.drawImage(video, 0, 0, pc.width, pc.height);
    const imageData = pctx.getImageData(0, 0, pc.width, pc.height);

    // Fast QR decode; avoid inversion attempts for speed
    const qr = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert',
    });

    if (qr && qr.data) {
      // If QR changed, look up student once
      if (qr.data !== currentQr) {
        setCurrentQr(qr.data);
        fetchStudent(qr.data);
      }

      // Auto-capture each page with a cooldown, regardless of same QR
      const now = Date.now();
      if (now - lastCaptureAtRef.current >= MIN_CAPTURE_INTERVAL_MS) {
        const img = captureHighResImage(video);
        if (img) {
          lastCaptureAtRef.current = now;
          const name = cachedStudentByQrRef.current.get(qr.data) ?? currentStudentName;
          const entry = {
            studentName: name || '',
            image: img,
            qrCode: qr.data,
            ts: now,
          };
          setScannedImages((prev) => [...prev, entry]);
          // Group by QR
          setGroupsByQr((prev) => {
            const next = { ...prev };
            if (!next[qr.data]) {
              next[qr.data] = { qrCode: qr.data, studentName: name || '', images: [] };
            }
            // Keep student name updated if resolved later
            if (name && next[qr.data].studentName !== name) {
              next[qr.data] = { ...next[qr.data], studentName: name };
            }
            next[qr.data] = {
              ...next[qr.data],
              images: [...next[qr.data].images, { image: img, ts: now }],
            };
            return next;
          });
        }
      }
    }
  }, [isScanning, currentQr, ensureCanvases, captureHighResImage, fetchStudent, currentStudentName]);

  // rAF loop
  useEffect(() => {
    if (!isScanning) return;
    const tick = (ts) => {
      processFrame(ts);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
  }, [isScanning, processFrame]);

  const handleComplete = useCallback(async () => {
    setIsScanning(false);
    try {
      // Build payload: array of students with multiple images per student
      const students = Object.values(groupsByQr).map((g) => ({
        qrCode: g.qrCode,
        studentName: g.studentName,
        images: g.images.map((im) => ({ image: im.image, ts: im.ts })),
      }));
      await axios.post('/upload_scanned_images/', { students });
      alert('Images uploaded successfully! Starting new batch.');
      setScannedImages([]);
      setGroupsByQr({});
      setCurrentStudentName('');
      setCurrentQr(null);
      // Keep cache so we don’t refetch if continue scanning same batch
      setIsScanning(true);
    } catch (err) {
      setError('Failed to upload images');
      console.error(err);
      setIsScanning(true); // Allow scanning to continue on failure
    }
  }, [groupsByQr]); // Removed scannedImages dependency as it's derivable from groupsByQr

  // Base styles for the main purple-to-orange gradient buttons
  const baseGradientButton = "inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-white shadow-xl disabled:opacity-60 bg-gradient-to-r from-purple-600 to-orange-500 hover:from-purple-500 hover:to-orange-400 transition-all duration-300 ease-in-out font-bold uppercase tracking-wider text-sm";
  // Secondary button for modals (using the gradient but smaller/different radius) - Cleaned up to be icon-only for list
  const modalIconButton = "inline-flex items-center justify-center w-8 h-8 rounded-full text-white shadow-md bg-purple-500 hover:bg-purple-600 transition-all duration-200";
  const modalDeleteButton = "inline-flex items-center justify-center w-8 h-8 rounded-full text-white shadow-md bg-red-500 hover:bg-red-600 transition-all duration-200";


  return (
    <div className="flex flex-col items-center justify-start min-h-screen bg-gradient-to-br from-purple-100 to-orange-100 p-4 sm:p-6">
      <h1 className="text-2xl sm:text-3xl mb-4 sm:mb-6 font-extrabold text-gray-800 drop-shadow-md">Answer Sheet Scanner</h1>
      {error && <p className="text-red-500 mb-4 font-medium">{error}</p>}
      
      {/* TWO COLUMN VIEW FOR LARGE SCREENS */}
      <div className="w-full max-w-7xl lg:grid lg:grid-cols-2 lg:gap-8">
        
        {/* LEFT COLUMN: WEBCAM AND CONTROLS */}
        <div className="lg:order-1 flex flex-col items-center w-full max-w-md mx-auto lg:max-w-full">
          <div className="relative w-full">
            {/* Students list button - Improved design */}
            <div className="absolute top-3 right-3 z-20">
  <button
    onClick={() => setShowStudentsModal(true)}
    className="relative flex items-center gap-2 bg-white/95 hover:bg-white text-gray-900 font-medium text-sm px-3 py-2.5 rounded-full shadow-lg ring-1 ring-black/10 transition-all duration-300"
    title="View Uploaded Students"
  >
    <div className="relative">
      <Users className="w-5 h-5 text-purple-600" />
      {Object.keys(groupsByQr).length > 0 && (
        <span className="absolute -top-2.5 -right-2 bg-red-500 text-white text-[10px] font-bold p-1.5 rounded-full leading-none">
          {Object.keys(groupsByQr).length}
        </span>
      )}
    </div>
  </button>
</div>

            <Webcam
              audio={false}
              ref={webcamRef}
              screenshotFormat="image/jpeg"
              className="w-full rounded-2xl shadow-2xl ring-2 ring-white/50"
              videoConstraints={{ facingMode: 'environment' }}
            />
            <div className="absolute top-3 left-3 bg-black/70 text-white px-3 py-1.5 rounded-xl text-sm font-medium backdrop-blur">
              {currentStudentName ? `Scanning: ${currentStudentName}` : currentQr ? 'Resolving student…' : 'Show page QR to camera'}
            </div>
            <div className="absolute bottom-3 right-3 bg-black/70 text-white px-3 py-1 rounded-xl text-xs backdrop-blur">Total Captured: {scannedImages.length}</div>
          </div>
        </div>

        {/* RIGHT COLUMN: THUMBNAILS/STUDENT DATA */}
        <div className="lg:order-2 mt-6 lg:mt-0 w-full max-w-md mx-auto lg:max-w-full lg:max-h-[85vh] lg:overflow-y-auto lg:pr-2">
          {/* Current student's thumbnails row */}
          <div className="w-full">
            <h2 className="text-xl font-bold mb-2 text-gray-700 drop-shadow">
              Current Student Pages
            </h2>
            <p className="text-sm text-gray-500 mb-3">
              {currentStudentName ? `Student: ${currentStudentName}` : 'No QR code detected recently.'}
            </p>
            <div className="flex gap-3 overflow-x-auto py-2 scrollbar-thin scrollbar-thumb-purple-300 scrollbar-track-transparent">
              {(() => {
                const imgs = groupsByQr[currentQr]?.images || [];
                const total = imgs.length;
                // Reverse so newest on the left; limit to last 20
                const display = imgs.slice(-20).reverse();
                return display.length > 0 ? (
                  display.map((im, idx) => {
                    const pageNum = total - idx; // newest gets highest number
                    return (
                      <button
                        key={im.ts}
                        className="relative flex-shrink-0 w-28 h-36 rounded-xl overflow-hidden border-2 border-white shadow-xl hover:shadow-2xl hover:ring-2 hover:ring-purple-400 bg-white/95 backdrop-blur transition-all duration-300 ease-in-out"
                        onClick={() => setViewerImage({ qrCode: currentQr, ts: im.ts, image: im.image })}
                        title={`Page ${pageNum} for ${currentStudentName}`}
                      >
                        <img src={im.image} alt={`Page ${pageNum}`} className="w-full h-full object-cover" />
                        <span className="absolute top-1 left-1 px-2 py-0.5 text-xs font-bold rounded-lg bg-black/70 text-white shadow-md">
                          Page {pageNum}
                        </span>
                        <Eye className="absolute bottom-1 right-1 w-5 h-5 text-white bg-black/70 p-0.5 rounded-full"/>
                      </button>
                    );
                  })
                ) : (
                  <p className="text-gray-500 italic">Capturing pages automatically when a QR code is stable.</p>
                );
              })()}
            </div>
          </div>
          
          <div className="mt-6 flex gap-3 justify-end">
            <button
              onClick={handleComplete}
              className={baseGradientButton}
              disabled={scannedImages.length === 0}
            >
             <CloudUpload className="w-5 h-5" /> 
             Upload {scannedImages.length} Sheets
            </button>
          </div>
        </div>
      </div>
      
      {/* Fullscreen image viewer - Improved button icons and styles */}
      {viewerImage && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="relative max-w-5xl w-full">
            <img src={viewerImage.image} alt="full" className="w-full max-h-[90vh] object-contain rounded-lg shadow-2xl" />
            <div className="absolute top-4 right-4 flex gap-3">
              <button
                className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-red-600 text-white shadow-lg hover:bg-red-700 transition-all duration-200"
                onClick={() => {
                  // remove this image from group and from global list
                  const { qrCode, ts } = viewerImage;
                  setGroupsByQr((prev) => {
                    const next = { ...prev };
                    if (!next[qrCode]) return prev;
                    next[qrCode] = {
                      ...next[qrCode],
                      images: next[qrCode].images.filter((x) => x.ts !== ts),
                    };
                    return next;
                  });
                  setScannedImages((prev) => prev.filter((x) => !(x.qrCode === qrCode && x.ts === ts)));
                  setViewerImage(null);
                }}
                title="Delete Page"
              >
                <Trash2 className="w-5 h-5" />
              </button>
              <button
                className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white text-gray-900 shadow-lg hover:bg-gray-100 transition-all duration-200"
                onClick={() => setViewerImage(null)}
                title="Close Viewer"
              >
                <X className="w-5 h-5" />                
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Students modal - Improved listing and icons */}
      {showStudentsModal && (
        <div className="fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="bg-white/95 backdrop-blur rounded-2xl shadow-2xl w-full max-w-4xl max-h-[85vh] overflow-hidden flex flex-col transform transition-all duration-300 scale-100 opacity-100">
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h3 className="text-xl font-bold text-gray-800">Uploaded Answer Sheets</h3>
              <button className="text-gray-500 hover:text-black p-1 rounded-full hover:bg-gray-100" onClick={() => { setShowStudentsModal(false); setStudentModalQr(null); }} title="Close">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {!studentModalQr && (
                <ul className="divide-y divide-gray-200">
                  {Object.values(groupsByQr).length === 0 && (
                    <li className="p-6 text-gray-500 italic">No students captured yet. Start scanning!</li>
                  )}
                  {Object.values(groupsByQr).map((g) => (
                    <li key={g.qrCode} className="px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-gray-50 transition-colors">
                      <div className="min-w-0 flex-1">
                        <div className="text-lg font-semibold text-gray-800 truncate">{g.studentName || 'Unknown Student'}</div>
                        <div className="text-sm text-gray-500">Pages Captured: <span className="font-medium text-gray-700">{g.images.length}</span></div>
                      </div>
                      <div className="flex items-center gap-2 mt-2 sm:mt-0">
                        {/* Improved Icon Buttons for actions */}
                        <button className={modalIconButton} onClick={() => setStudentModalQr(g.qrCode)} title="View Pages">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          className={modalDeleteButton}
                          onClick={() => {
                            setGroupsByQr((prev) => {
                              const next = { ...prev };
                              delete next[g.qrCode];
                              return next;
                            });
                            setScannedImages((prev) => prev.filter((x) => x.qrCode !== g.qrCode));
                          }}
                          title="Remove Student"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </li>) )}
                </ul>
              )}
              {studentModalQr && (
                <div className="p-4">
                  <div className="flex items-center  mb-4 pb-2 border-b">
                  <button className=" items-center gap-1.5 text-sm font-medium text-purple-600 hover:text-purple-800 transition-colors" onClick={() => setStudentModalQr(null)}>
                      <ChevronLeft size={26} />
                    </button>
                    <div>
                      <div className="text-lg font-bold text-gray-800">{groupsByQr[studentModalQr]?.studentName || 'Unknown Student'}</div>
                      <div className="text-xs text-gray-500">Total Pages: {groupsByQr[studentModalQr]?.images.length || 0}</div>
                    </div>
                    {/* Consistent Back Button with Icon */}
                   
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {(groupsByQr[studentModalQr]?.images || []).map((im, i) => (
                      <div key={im.ts} className="relative group rounded-lg overflow-hidden border border-gray-200 shadow-md hover:shadow-lg transition-shadow bg-white">
                        <img src={im.image} alt={`thumb page ${i + 1}`} className="w-full h-32 object-cover" />
                        <span className="absolute top-1 left-1 px-2 py-0.5 text-xs font-bold rounded-full bg-black/70 text-white shadow">
                          Pg {i + 1}
                        </span>
                        {/* Action buttons on hover/group-hover */}
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="flex gap-2">
                            <button
                              className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-white/90 text-gray-900 shadow-md hover:bg-white transition-all"
                              onClick={() => setViewerImage({ qrCode: studentModalQr, ts: im.ts, image: im.image })}
                              title="View Page"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              className="hidden items-center justify-center w-8 h-8 rounded-full bg-red-600 text-white shadow-md hover:bg-red-700 transition-all"
                              onClick={() => {
                                setGroupsByQr((prev) => {
                                  const next = { ...prev };
                                  if (!next[studentModalQr]) return prev;
                                  next[studentModalQr] = {
                                    ...next[studentModalQr],
                                    images: next[studentModalQr].images.filter((x) => x.ts !== im.ts),
                                  };
                                  return next;
                                });
                                setScannedImages((prev) => prev.filter((x) => !(x.qrCode === studentModalQr && x.ts === im.ts)));
                              }}
                              title="Remove Page"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Scanner;