import React, { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import jsQR from 'jsqr';
import axios from '../api';

// Tunables for performance and UX
const PROCESS_FPS = 10; // Max QR processing rate
const MIN_CAPTURE_INTERVAL_MS = 1200; // Minimum time between auto-captures
const DOWNSCALE_WIDTH = 640; // Downscale width for QR processing

const Scanner = () => {
  const webcamRef = useRef(null);
  const processCanvasRef = useRef(null); // reused canvas for QR decoding
  const captureCanvasRef = useRef(null); // reused canvas for high-res capture

  const [currentStudentName, setCurrentStudentName] = useState('');
  const [scannedImages, setScannedImages] = useState([]);
  const [currentQr, setCurrentQr] = useState(null);
  const [isScanning, setIsScanning] = useState(true);
  const [error, setError] = useState('');
  const [groupsByQr, setGroupsByQr] = useState({}); // { [qr]: { qrCode, studentName, images: [{image, ts}] } }

  // UI state: modals and viewer
  const [showStudentsModal, setShowStudentsModal] = useState(false);
  const [studentModalQr, setStudentModalQr] = useState(null); // which student to view in modal
  const [viewerImage, setViewerImage] = useState(null); // { qrCode, ts, image }

  // Refs for timing and caching to avoid re-renders in tight loop
  const lastCaptureAtRef = useRef(0);
  const lastProcessAtRef = useRef(0);
  const cachedStudentByQrRef = useRef(new Map());
  const rafRef = useRef(null);

  const ensureCanvases = useCallback((video) => {
    if (!processCanvasRef.current) {
      processCanvasRef.current = document.createElement('canvas');
    }
    if (!captureCanvasRef.current) {
      captureCanvasRef.current = document.createElement('canvas');
    }

    // Setup sizes
    const aspect = video.videoHeight / Math.max(1, video.videoWidth);
    const targetW = Math.min(DOWNSCALE_WIDTH, video.videoWidth);
    const targetH = Math.round(targetW * aspect);
    processCanvasRef.current.width = targetW;
    processCanvasRef.current.height = targetH;

    // Full-res capture canvas uses the video’s native resolution
    captureCanvasRef.current.width = video.videoWidth;
    captureCanvasRef.current.height = video.videoHeight;
  }, []);

  const fetchStudent = useCallback(async (qrValue) => {
    // Serve from cache if available
    if (cachedStudentByQrRef.current.has(qrValue)) {
      const cached = cachedStudentByQrRef.current.get(qrValue);
      setCurrentStudentName(cached);
      // propagate to groups store
      setGroupsByQr((prev) => (prev[qrValue] ? { ...prev, [qrValue]: { ...prev[qrValue], studentName: cached } } : prev));
      return cached;
    }
    try {
      const response = await axios.post('/get_students_name/', { qrCode: qrValue });
      const { studentName } = response.data;
      cachedStudentByQrRef.current.set(qrValue, studentName || '');
      setCurrentStudentName(studentName || '');
      // propagate to groups store
      setGroupsByQr((prev) => (prev[qrValue] ? { ...prev, [qrValue]: { ...prev[qrValue], studentName: studentName || '' } } : prev));
      return studentName || '';
    } catch (err) {
      console.error(err);
      setError('Failed to fetch student name');
      return '';
    }
  }, []);

  const captureHighResImage = useCallback((video) => {
    if (!captureCanvasRef.current) return null;
    const c = captureCanvasRef.current;
    const ctx = c.getContext('2d', { willReadFrequently: false });
    ctx.drawImage(video, 0, 0, c.width, c.height);
    // High-quality JPEG
    return c.toDataURL('image/jpeg', 0.9);
  }, []);

  const processFrame = useCallback(async (nowTs) => {
    if (!isScanning || !webcamRef.current) return;

    const video = webcamRef.current.video;
    if (!video || video.readyState < 2) return; // video not ready

    // Throttle processing to PROCESS_FPS
    const sinceLast = nowTs - lastProcessAtRef.current;
    const minDelta = 1000 / PROCESS_FPS;
    if (sinceLast < minDelta) return;
    lastProcessAtRef.current = nowTs;

    ensureCanvases(video);

    // Downscale and read pixels for QR
    const pc = processCanvasRef.current;
    const pctx = pc.getContext('2d', { willReadFrequently: true });
    pctx.drawImage(video, 0, 0, pc.width, pc.height);
    const imageData = pctx.getImageData(0, 0, pc.width, pc.height);

    // Fast QR decode; avoid inversion attempts for speed
    const qr = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert',
    });

    if (qr && qr.data) {
      // If QR changed, look up student once
      if (qr.data !== currentQr) {
        setCurrentQr(qr.data);
        fetchStudent(qr.data);
      }

      // Auto-capture each page with a cooldown, regardless of same QR
      const now = Date.now();
      if (now - lastCaptureAtRef.current >= MIN_CAPTURE_INTERVAL_MS) {
        const img = captureHighResImage(video);
        if (img) {
          lastCaptureAtRef.current = now;
          const name = cachedStudentByQrRef.current.get(qr.data) ?? currentStudentName;
          const entry = {
            studentName: name || '',
            image: img,
            qrCode: qr.data,
            ts: now,
          };
          setScannedImages((prev) => [...prev, entry]);
          // Group by QR
          setGroupsByQr((prev) => {
            const next = { ...prev };
            if (!next[qr.data]) {
              next[qr.data] = { qrCode: qr.data, studentName: name || '', images: [] };
            }
            // Keep student name updated if resolved later
            if (name && next[qr.data].studentName !== name) {
              next[qr.data] = { ...next[qr.data], studentName: name };
            }
            next[qr.data] = {
              ...next[qr.data],
              images: [...next[qr.data].images, { image: img, ts: now }],
            };
            return next;
          });
        }
      }
    }
  }, [isScanning, currentQr, ensureCanvases, captureHighResImage, fetchStudent, currentStudentName]);

  // rAF loop
  useEffect(() => {
    if (!isScanning) return;
    const tick = (ts) => {
      processFrame(ts);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
  }, [isScanning, processFrame]);

  const handleComplete = useCallback(async () => {
    setIsScanning(false);
    try {
      // Build payload: array of students with multiple images per student
      const students = Object.values(groupsByQr).map((g) => ({
        qrCode: g.qrCode,
        studentName: g.studentName,
        images: g.images.map((im) => ({ image: im.image, ts: im.ts })),
      }));
      await axios.post('/upload_scanned_images/', { students });
      alert('Images uploaded successfully!');
      setScannedImages([]);
      setGroupsByQr({});
      setCurrentStudentName('');
      setCurrentQr(null);
      // Keep cache so we don’t refetch if continue scanning same batch
      setIsScanning(true);
    } catch (err) {
      setError('Failed to upload images');
      console.error(err);
    }
  }, [groupsByQr, scannedImages]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4">Answer Sheet Scanner</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      <div className="relative w-full max-w-md">
        {/* Students list button */}
        <button
          onClick={() => setShowStudentsModal(true)}
          className="absolute top-2 right-2 z-20 bg-white/80 hover:bg-white text-gray-900 text-sm px-3 py-1 rounded shadow"
        >
          Students
        </button>
        <Webcam
          audio={false}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          className="w-full rounded-lg shadow-lg"
          videoConstraints={{ facingMode: 'environment' }}
        />
        <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white p-2 rounded">
          {currentStudentName ? `Scanning: ${currentStudentName}` : currentQr ? 'Resolving student…' : 'Show page QR to camera'}
        </div>
        <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">Captured: {scannedImages.length}</div>
      </div>
      {/* Current student's thumbnails row */}
      <div className="mt-4 w-full max-w-md">
        <h2 className="text-lg font-semibold">
          {currentStudentName ? `Recent Captures — ${currentStudentName}` : 'Recent Captures'}
        </h2>
        <div className="mt-2 flex gap-3 overflow-x-auto py-1">
          {(() => {
            const imgs = groupsByQr[currentQr]?.images || [];
            const total = imgs.length;
            // Reverse so newest on the left; limit to last 20
            const display = imgs.slice(-20).reverse();
            return display.map((im, idx) => {
              const pageNum = total - idx; // newest gets highest number
              return (
                <button
                  key={im.ts}
                  className="relative flex-shrink-0 w-24 h-32 rounded overflow-hidden border border-gray-200 shadow-sm hover:ring-2 hover:ring-blue-400 bg-white"
                  onClick={() => setViewerImage({ qrCode: currentQr, ts: im.ts, image: im.image })}
                  title={`Page ${pageNum}`}
                >
                  <img src={im.image} alt={`Page ${pageNum}`} className="w-full h-full object-cover" />
                  <span className="absolute top-1 left-1 px-1.5 py-0.5 text-[10px] font-semibold rounded bg-black/70 text-white">
                    Pg {pageNum}
                  </span>
                </button>
              );
            });
          })()}
        </div>
      </div>
      <div className="mt-4 flex gap-3">
        <button
          onClick={() => setIsScanning((s) => !s)}
          className="bg-gray-700 text-white px-4 py-2 rounded hover:bg-gray-800"
        >
          {isScanning ? 'Pause' : 'Resume'}
        </button>
        <button
          onClick={handleComplete}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 disabled:bg-gray-400"
          disabled={scannedImages.length === 0}
        >
          Complete
        </button>
      </div>

      {/* Fullscreen image viewer */}
      {viewerImage && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="relative max-w-4xl w-full">
            <img src={viewerImage.image} alt="full" className="w-full max-h-[80vh] object-contain rounded" />
            <div className="absolute top-2 right-2 flex gap-2">
              <button
                className="bg-red-600 text-white px-3 py-1 rounded shadow hover:bg-red-700"
                onClick={() => {
                  // remove this image from group and from global list
                  const { qrCode, ts } = viewerImage;
                  setGroupsByQr((prev) => {
                    const next = { ...prev };
                    if (!next[qrCode]) return prev;
                    next[qrCode] = {
                      ...next[qrCode],
                      images: next[qrCode].images.filter((x) => x.ts !== ts),
                    };
                    return next;
                  });
                  setScannedImages((prev) => prev.filter((x) => !(x.qrCode === qrCode && x.ts === ts)));
                  setViewerImage(null);
                }}
              >
                Remove Image
              </button>
              <button
                className="bg-white text-gray-900 px-3 py-1 rounded shadow hover:bg-gray-100"
                onClick={() => setViewerImage(null)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Students modal */}
      {showStudentsModal && (
        <div className="fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h3 className="text-lg font-semibold">Students</h3>
              <button className="text-gray-600 hover:text-black" onClick={() => { setShowStudentsModal(false); setStudentModalQr(null); }}>✕</button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {!studentModalQr && (
                <ul className="divide-y">
                  {Object.values(groupsByQr).length === 0 && (
                    <li className="p-4 text-gray-500">No students captured yet.</li>
                  )}
                  {Object.values(groupsByQr).map((g) => (
                    <li key={g.qrCode} className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-medium truncate">{g.studentName || 'Unknown'}</div>
                        <div className="text-xs text-gray-500">QR: {g.qrCode}</div>
                        <div className="text-xs text-gray-500">Images: {g.images.length}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600" onClick={() => setStudentModalQr(g.qrCode)}>View</button>
                        <button
                          className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                          onClick={() => {
                            setGroupsByQr((prev) => {
                              const next = { ...prev };
                              delete next[g.qrCode];
                              return next;
                            });
                            setScannedImages((prev) => prev.filter((x) => x.qrCode !== g.qrCode));
                          }}
                        >
                          Remove All
                        </button>
                      </div>
                    </li>) )}
                </ul>
              )}
              {studentModalQr && (
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="font-semibold">{groupsByQr[studentModalQr]?.studentName || 'Unknown'}</div>
                      <div className="text-xs text-gray-500">QR: {studentModalQr}</div>
                    </div>
                    <button className="text-sm text-blue-600 hover:underline" onClick={() => setStudentModalQr(null)}>Back</button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                    {(groupsByQr[studentModalQr]?.images || []).map((im, i) => (
                      <div key={im.ts} className="relative group rounded overflow-hidden border">
                        <img src={im.image} alt={`thumb page ${i + 1}`} className="w-full h-32 object-cover" />
                        <span className="absolute top-1 left-1 px-1.5 py-0.5 text-[10px] font-semibold rounded bg-black/70 text-white">
                          Pg {i + 1}
                        </span>
                        <div className="absolute top-1 right-1 hidden group-hover:flex gap-1">
                          <button
                            className="bg-white/90 text-gray-900 text-xs px-2 py-1 rounded shadow"
                            onClick={() => setViewerImage({ qrCode: studentModalQr, ts: im.ts, image: im.image })}
                          >
                            View
                          </button>
                          <button
                            className="bg-red-600 text-white text-xs px-2 py-1 rounded shadow"
                            onClick={() => {
                              setGroupsByQr((prev) => {
                                const next = { ...prev };
                                if (!next[studentModalQr]) return prev;
                                next[studentModalQr] = {
                                  ...next[studentModalQr],
                                  images: next[studentModalQr].images.filter((x) => x.ts !== im.ts),
                                };
                                return next;
                              });
                              setScannedImages((prev) => prev.filter((x) => !(x.qrCode === studentModalQr && x.ts === im.ts)));
                            }}
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Scanner;