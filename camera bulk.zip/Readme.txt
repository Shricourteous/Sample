get_students_name/    POST

qrCode : {"fk_class_key":"class00000000007","fk_school_key":"05A74397DA34095F","fk_school_class_key":"89D6D574E2A10907","questionpaperkey":"CNCWG0V415A46U19","pk_student_key":"018459137A7F9E2B"}


response:

{
    "valid": true,
    "message": "QR code data is invalid.",
    "studentName": "Jhone Doe",
    "studentId": "12w345"
}


upload_scanned_images/    POST

Payload
{
    "students": [
        {
            "qrCode": "{\"fk_class_key\":\"class00000000007\",\"fk_school_key\":\"05A74397DA34095F\",\"fk_school_class_key\":\"89D6D574E2A10907\",\"questionpaperkey\":\"CNCWG0V415A46U19\",\"pk_student_key\":\"018459137A7F9E2B\"}",
            "studentName": "Jhone Doe",
            "images": [
                {
                    "image": "data:image/jpeg;base64,
                    "ts": 1759942175788
                }
            ]
        }
    ]
}


response:
{"valid":true,"message":"QR code is valid.","qr_data":"VALID-QR-12345"}