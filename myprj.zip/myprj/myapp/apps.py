import os
import logging
from django.apps import AppConfig
from django.conf import settings

logger = logging.getLogger('apscheduler')


class MyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myapp'

    def ready(self):
        # In dev, Django runs autoreload which spawns a child process; start only in the child.
        if os.environ.get('RUN_MAIN') != 'true':
            return

        # Ensure the logs directory exists for file handlers configured in settings.LOGGING
        logs_dir = os.path.join(settings.BASE_DIR, 'logs')
        os.makedirs(logs_dir, exist_ok=True)

        # Avoid starting multiple times if ready() is called more than once in this process
        if getattr(self, '_scheduler_started', False):
            logger.info('APScheduler already started in this process')
            return

        try:
            from .scheduler import create_scheduler
            from .jobs import setup_jobs

            scheduler = create_scheduler()
            setup_jobs(scheduler)
            scheduler.start()

            self._scheduler_started = True
            self.scheduler = scheduler

            logger.info('APScheduler started with jobs: %s', [job.id for job in scheduler.get_jobs()])
        except Exception as e:
            logger.error('Failed to start APScheduler: %s', e, exc_info=True)
