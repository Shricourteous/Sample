"""
This module contains all the scheduled jobs for the application.
"""
import logging
import time
from datetime import datetime

from .task import expensive_tasks

logger = logging.getLogger('apscheduler')

def run_expensive_task():
    """
    Wrapper job that runs the expensive_tasks function.
    Runs every 30 seconds (configured by setup_jobs).
    """
    start = time.time()
    try:
        logger.info("Starting expensive task...")
        result = expensive_tasks()
        elapsed = time.time() - start
        logger.info(f"Expensive task finished (result={result}) in {elapsed:.2f}s")
    except Exception as e:
        logger.error(f"Error in run_expensive_task: {e}", exc_info=True)
        raise


def setup_jobs(scheduler):
    """
    Register scheduled jobs with the provided scheduler.
    Schedules run_expensive_task every 30 seconds.
    """
    try:
        scheduler.add_job(
            run_expensive_task,
            'interval',
            seconds=30,
            id='run_expensive_task_every_30s',
            max_instances=1,
            replace_existing=True,
            misfire_grace_time=15,  # tolerate small delays
        )
        logger.info("Registered job: run_expensive_task_every_30s (every 30 seconds)")
    except Exception as e:
        logger.error(f"Error registering jobs: {e}", exc_info=True)
        raise
