import time

def expensive_tasks():
    start_time = time.time()  # Record start time
    end_time = time.time()    # Record end time
    
    runtime = end_time - start_time
    log_message = f"Running time: {runtime:.2f} seconds\n"
    
    # Open file in append mode and write the log
    with open("runtime_log.txt", "a") as f:
        f.write(log_message)
    
    print(log_message)
    # Some time consuming process
    time.sleep(10)
    print("Expensive task completed")
    return True
