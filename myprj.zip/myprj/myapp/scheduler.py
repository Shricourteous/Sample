import logging
import sys
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.executors.pool import ProcessPoolExecutor, ThreadPoolExecutor
from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED
from django.conf import settings

# Set up logging
logger = logging.getLogger('apscheduler')

def _job_event_listener(event):
    """
    Listener to log job execution results and errors.
    """
    try:
        if event.exception:
            logger.error(
                "Job %s failed. Traceback available in logs.",
                getattr(event, 'job_id', 'unknown'),
                exc_info=True,
            )
        else:
            logger.info(
                "Job %s executed successfully.",
                getattr(event, 'job_id', 'unknown'),
            )
    except Exception as e:
        logger.error("Error in job event listener: %s", e, exc_info=True)


def create_scheduler():
    """
    Create and return an in-memory BackgroundScheduler with sensible defaults.
    Scheduler is NOT started here; caller should call scheduler.start().
    """
    # Configure executors (no DB job stores)
    executors = {
        'default': ThreadPoolExecutor(20),
        'processpool': ProcessPoolExecutor(5),
    }

    job_defaults = {
        'coalesce': False,
        'max_instances': 1,
        'misfire_grace_time': 30,  # seconds
    }

    scheduler = BackgroundScheduler(
        executors=executors,
        job_defaults=job_defaults,
        timezone=settings.TIME_ZONE,
    )

    # Add listeners for job executed and job error events
    scheduler.add_listener(_job_event_listener, EVENT_JOB_EXECUTED | EVENT_JOB_ERROR)

    logger.info("APScheduler created (in-memory, no DB job store)")
    return scheduler
