from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response
from rest_framework.decorators import api_view
from PIL import Image

import os
import time
from django.conf import settings
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response

import os
import time
from django.conf import settings
from PIL import Image
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response


@api_view(['POST'])
@parser_classes([MultiPartParser, FormParser])
def images_to_pdf(request):
    files = request.FILES.getlist('files')  # multiple images

    if not files:
        return Response({"error": "No files provided"}, status=400)

    images = []
    for file in files:
        try:
            img = Image.open(file)
            img = img.convert("RGB")  # convert to RGB (PDF doesn’t support RGBA)
            images.append(img)
        except Exception as e:
            return Response({"error": f"Invalid image file: {file.name}, {str(e)}"}, status=400)

    if not images:
        return Response({"error": "No valid images found"}, status=400)

    # Generate PDF filename with timestamp
    timestamp = int(time.time())
    filename = f"{timestamp}.pdf"
    save_path = os.path.join(settings.MEDIA_ROOT, filename)
    os.makedirs(settings.MEDIA_ROOT, exist_ok=True)

    # Save first image, append the rest
    images[0].save(save_path, save_all=True, append_images=images[1:])

    file_url = f"{settings.MEDIA_URL}{filename}"
    return Response({"message": "PDF created successfully", "file_url": file_url})


from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from PIL import Image
from pyzbar.pyzbar import decode
import io

@api_view(['POST'])
@parser_classes([MultiPartParser, FormParser])
def check_valid_qr(request):
    """
    Receives an image file, decodes any QR codes within it,
    and checks if the decoded data is valid.
    """
    if 'file' not in request.FILES:
        return Response({'valid': False, 'message': 'No image file provided.'}, status=400)

    qr_image = request.FILES['file']
    
    try:
        # Read the image data into memory
        img = Image.open(io.BytesIO(qr_image.read()))
        decoded_objects = decode(img)

        if not decoded_objects:
            return Response({'valid': False, 'message': 'No QR code found in the image.'})

        # Assuming there's only one QR code to check
        qr_data = decoded_objects[0].data.decode('utf-8')
        
        # Define your validation logic here. This is a mock example.
        # In a real application, you would check this against a database.
        if qr_data.startswith("VALID-QR-"):
            return Response({'valid': True, 'message': 'QR code is valid.', 'qr_data': qr_data})
        else:
            return Response({'valid': False, 'message': 'QR code data is invalid.'})

    except Exception as e:
        return Response({'valid': False, 'message': f'Error processing QR code: {str(e)}'}, status=500)


import time

@api_view(['POST'])
def trigger_APScheduler(request):
            
    try:
        # tasks
        time.sleep(3)
        return Response({'valid': True, 'message': 'Started'})

    except Exception as e:
        return Response({'valid': False, 'message': f'Error processing QR code: {str(e)}'}, status=500)
