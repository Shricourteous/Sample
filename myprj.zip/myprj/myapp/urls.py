from django.urls import path
from .views import *

urlpatterns = [
    path('upload-pdf/', images_to_pdf, name='upload-pdf'),
    path('check-valid-qr/', check_valid_qr, name='check-valid-qr'),
    path('trigger_APScheduler/', trigger_APScheduler, name='trigger_APScheduler')
    
]
